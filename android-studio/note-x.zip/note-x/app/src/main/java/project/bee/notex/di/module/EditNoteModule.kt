package project.bee.notex.di.module

import android.app.Activity
import dagger.Module
import dagger.Provides
import io.reactivex.Scheduler
import project.bee.notex.database.NoteDatabaseImpl
import project.bee.notex.di.scope.IoThread
import project.bee.notex.di.scope.MainThread
import project.bee.notex.di.scope.EditNoteScope
import project.bee.notex.ui.editnote.*
import project.bee.notex.ui.notelist.*

@Module
class EditNoteModule(val activity: Activity) {
    @Provides
    fun provideActivity() = activity

    @EditNoteScope
    @Provides
    fun provideEditNotePresenter(useCase: EditNoteUseCase,
                                 @IoThread ioScheduler: Scheduler,
                                 @MainThread EditNoteScheduler: Scheduler): EditNoteContract.Presenter =
            EditNotePresenterImpl(useCase, ioScheduler, EditNoteScheduler)

    @EditNoteScope
    @Provides
    fun provideEditNoteUseCase(repo: EditNoteRepo): EditNoteUseCase = EditNoteUseCaseImpl(repo)

    @EditNoteScope
    @Provides
    fun provideEditNoteRepo(database: NoteDatabaseImpl): EditNoteRepo = EditNoteRepoImpl(database)
}