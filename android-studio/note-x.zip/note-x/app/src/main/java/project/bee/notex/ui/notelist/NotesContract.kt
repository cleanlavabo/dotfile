package project.bee.notex.ui.notelist

import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import project.bee.notex.database.entity.Note

class NotesContract {
    interface View {
        fun setupViews()
        fun getNotebookId(): String
        fun submitNotes(notes: List<Note>, callback: Runnable)
        fun scrollTo(pos: Int)
        fun addNoteClicks(): Observable<Any>
        fun notebookTitleClicks(): Observable<Boolean>
        fun showVersionDialog()
        fun noteClicks(): PublishSubject<Note>
        fun startEditNoteActivity(note: Note)
    }

    interface Presenter {
        fun destroy()
        fun create()
        fun attachView(view: View)
        fun loadData(notebookId: String)
        fun handleError(it: Throwable)
        fun setupEvent()
    }
}