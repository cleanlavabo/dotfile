package project.bee.notex.ui.notelist

import io.reactivex.Scheduler
import io.reactivex.disposables.CompositeDisposable
import project.bee.notex.data.DataGenerator
import project.bee.notex.util.RxUtil
import timber.log.Timber

class NotesPresenterImpl(val useCase: NotesUseCase,
                         val io: Scheduler,
                         val main: Scheduler) : NotesContract.Presenter {
    private val notesLoadedCallback: Runnable by lazy {
        Runnable {
            view.scrollTo(0)
        }
    }

    private lateinit var view: NotesContract.View

    private val subscription: CompositeDisposable = CompositeDisposable()

    override fun attachView(view: NotesContract.View) {
        this.view = view
    }

    override fun create() {
        view.setupViews()
        loadData(view.getNotebookId())
        setupEvent()
    }

    override fun loadData(notebookId: String) {
        subscription.add(useCase.getNotes(notebookId)
                .subscribeOn(io)
                .observeOn(main)
                .subscribe({
                    view.submitNotes(it, notesLoadedCallback)
                }, {
                    Timber.i("${System.currentTimeMillis()}")
                    handleError(it)
                }))
    }

    override fun setupEvent() {
        subscription.add(view.addNoteClicks()
                .compose(RxUtil.withShortThrottleFirst())
                .observeOn(io)
                .subscribe({
                    useCase.addNote(DataGenerator.generateNote(view.getNotebookId()))
                }, {
                    handleError(it)
                }))

        subscription.add(view.notebookTitleClicks()
                .compose(RxUtil.withShortThrottleFirst())
                .observeOn(main)
                .subscribe({ debug ->
                    if (debug) {
                        view.showVersionDialog()
                    }
                }, {

                }))

        subscription.add(view.noteClicks()
                .compose(RxUtil.withShortThrottleFirst())
                .observeOn(main)
                .subscribe({ note ->
                    view.startEditNoteActivity(note)
                }, {

                }))
    }

    override fun handleError(it: Throwable) {
        Timber.e(it)
    }

    override fun destroy() {
        subscription.dispose()
    }
}