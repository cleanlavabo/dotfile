package project.bee.notex.ui.main

import io.reactivex.Observable

class MainContract {
    interface View {
        fun setupViews()
        fun setCategories(notebooks: MutableList<NotebookViewModel>)
        fun replaceFrag(notebook: NotebookViewModel)
        fun categoryClicks(): Observable<NotebookViewModel>
        fun settingClicks(): Observable<Any>
        fun categoriesClicks(): Observable<Any>
        fun deleteCategoryClicks(): Observable<Any>
        fun editCategoryClicks(): Observable<Any>
        fun dismissCategoryDialog()
        fun showSettingDialog()
        fun dismissSettingDialog()
        fun showCategoryDialog()
    }

    interface Presenter {
        fun attachView(view: View)
        fun destroy()
        fun create()
        fun loadData()
        fun setupEvents()
        fun categoryClicks()
        fun settingClicks()
        fun deleteCategoryClicks()
        fun editCategoryClicks()
        fun categoryListClicks()
        fun handleError(throwable: Throwable)
    }
}