package project.bee.notex.ui.notelist

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.jakewharton.rxbinding2.view.RxView
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import kotlinx.android.synthetic.main.fragment_note_list.*
import project.bee.notex.App
import project.bee.notex.BuildConfig
import project.bee.notex.R
import project.bee.notex.database.entity.Note
import project.bee.notex.database.entity.Notebook
import project.bee.notex.decoration.StandardItemDecorator
import project.bee.notex.di.module.NotesModule
import project.bee.notex.dialog.DialogManager
import project.bee.notex.ui.editnote.EditNoteActivity
import javax.inject.Inject

private const val ARG_CATEGORY = "arg-notebook"
private const val REQUEST_ADD_NOTE = 1
private const val REQUEST_EDIT_NOTE = 2

class NotesFragment : Fragment(), NotesContract.View {
    @Inject
    lateinit var presenter: NotesContract.Presenter

    val notebook: Notebook by lazy {
        arguments?.getParcelable(ARG_CATEGORY) ?: Notebook("")
    }

    private val noteAdapter: NoteAdapter? by lazy {
        context?.let {
            NoteAdapter(it)
        }
    }

    override fun getNotebookId(): String {
        return notebook.id
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        di()
        presenter.attachView(this)
    }

    override fun onDetach() {
        presenter.destroy()
        super.onDetach()
    }

    private fun di() {
        App.instance.appComponent
                .newNotesComponent(NotesModule(context as Activity))
                .inject(this)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return layoutInflater.inflate(R.layout.fragment_note_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        presenter.create()
    }

    override fun setupViews() {
        tvCategoryName.text = notebook.name

        rvNote?.apply {
            setHasFixedSize(true)
            addItemDecoration(StandardItemDecorator(resources.getDimensionPixelSize(R.dimen.spacing_small)))
            adapter = noteAdapter
        }
    }

    override fun submitNotes(notes: List<Note>, callback: Runnable) {
        noteAdapter?.submitList(notes.map {
            NoteViewModel(it)
        }, callback)
    }

    override fun scrollTo(pos: Int) {
        rvNote.scrollToPosition(pos)
    }

    override fun addNoteClicks(): Observable<Any> {
        return RxView.clicks(btnAddNote)
    }

    override fun notebookTitleClicks(): Observable<Boolean> {
        return RxView.clicks(tvCategoryName).map { BuildConfig.DEBUG }
    }

    override fun showVersionDialog() {
        DialogManager.showVersionDialog(context)
    }

    override fun noteClicks(): PublishSubject<Note> {
        return noteAdapter?.noteClickSubject ?: PublishSubject.create<Note>()
    }

    override fun startEditNoteActivity(note: Note) {
        context?.let {
            startActivity(EditNoteActivity.newEditNoteIntent(it, note))
        }
    }

//    fun addAndEditNote() {
//        startActivityEditNote(null, REQUEST_ADD_NOTE)
//    }
//
//    private fun addLocalNote(note: Note) {
//        compositeDisposable.add(Single
//                .fromCallable { NoteDatabase.instance(context!!).noteDao().addNote(note) }
//                .doOnDispose { Timber.i("Add local note success") }
//                .subscribeOn(Schedulers.io())
//                .subscribe())
//    }
//
//    private fun editLocalNote(note: Note) {
//        compositeDisposable.add(Observable
//                .fromCallable { NoteDatabase.instance(context!!).noteDao().editNote(note) }
//                .doOnDispose { Timber.i("Edit local note success") }
//                .subscribeOn(Schedulers.io())
//                .subscribe())
//    }
//
//    private fun removeLocalNote(note: Note) {
//        compositeDisposable.add(Observable
//                .fromCallable { NoteDatabase.instance(context!!).noteDao().removeNote(note) }
//                .doOnDispose { Timber.i("Remove local note success") }
//                .subscribeOn(Schedulers.io())
//                .subscribe())
//    }
//
//    private fun editNote(note: Note) {
//        startActivityEditNote(note, REQUEST_EDIT_NOTE)
//    }
//
//    private fun startActivityEditNote(note: Note?, requestCode: Int) {
//        context?.let { context ->
//            startActivityForResult(EditNoteActivity.newInstance(context, note), requestCode)
//        }
//    }
//
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        val note = data?.getParcelableExtra(EditNoteActivity.ARG_NOTE) as Note? ?: return
//        when (resultCode) {
//            RESULT_OK -> {
//                when (requestCode) {
//                    REQUEST_ADD_NOTE -> {
//                        if (!note.content.isEmpty()) {
//                            addLocalNote(note)
//                        }
//                    }
//                    REQUEST_EDIT_NOTE -> {
//                        when {
//                            note.content.isEmpty() -> {
//                                removeLocalNote(note)
//                            }
//                            else -> {
//                                editLocalNote(note)
//                            }
//                        }
//                    }
//                }
//            }
//            RESULT_CANCELED -> {
//                deleteNote(note)
//            }
//        }
//    }
//
//    private fun deleteNote(note: Note) {
//        note.isActive = false
//        editLocalNote(note)
//        showUndoBar(NoteViewModel(note))
//    }
//
//    private fun showUndoBar(viewModel: NoteViewModel) {
//        val contentDeleteNote = StringBuilder(resources.getString(R.string.content_deleted))
//                .append(" ")
//                .append(viewModel.title)
//        ViewUtil.showUndoBar(context, layoutNoteList, contentDeleteNote, View.OnClickListener {
//            viewModel.note.isActive = true
//            editLocalNote(viewModel.note)
//        })
//    }

    companion object {
        fun newInstance(notebook: Notebook) =
                NotesFragment().apply {
                    arguments = Bundle().apply {
                        putParcelable(ARG_CATEGORY, notebook)
                    }
                }
    }
}
