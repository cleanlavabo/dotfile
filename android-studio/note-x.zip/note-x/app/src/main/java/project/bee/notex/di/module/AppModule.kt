package project.bee.notex.di.module

import dagger.Module
import dagger.Provides
import io.reactivex.Scheduler
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import project.bee.notex.App
import project.bee.notex.database.NoteDatabase
import project.bee.notex.database.NoteDatabaseImpl
import project.bee.notex.di.scope.IoThread
import project.bee.notex.di.scope.MainThread
import javax.inject.Singleton

@Module
class AppModule(val app: App) {
    @Provides
    @Singleton
    fun provideApp() = app

    @Provides
    @IoThread
    fun provideIoScheduler(): Scheduler = Schedulers.io()

    @Provides
    @MainThread
    fun provideMainScheduler(): Scheduler = AndroidSchedulers.mainThread()

    @Provides
    fun provideDatabase(): NoteDatabaseImpl = NoteDatabase.instance(app)
}