package project.bee.notex.database.dao

import androidx.room.*
import androidx.room.OnConflictStrategy.REPLACE
import io.reactivex.Observable
import project.bee.notex.database.entity.Notebook

@Dao
interface NotebookDao {
    @Query("SELECT * from Notebook")
    fun getAll(): Observable<List<Notebook>>

    @Insert(onConflict = REPLACE)
    fun addNotebook(note: Notebook): Long?

    @Update
    fun editNote(note: Notebook)

    @Delete
    fun removeNote(vararg note: Notebook)
}