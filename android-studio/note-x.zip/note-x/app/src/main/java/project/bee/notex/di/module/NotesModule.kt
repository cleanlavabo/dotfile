package project.bee.notex.di.module

import android.app.Activity
import dagger.Module
import dagger.Provides
import io.reactivex.Scheduler
import project.bee.notex.database.NoteDatabaseImpl
import project.bee.notex.di.scope.IoThread
import project.bee.notex.di.scope.MainThread
import project.bee.notex.di.scope.NotesScope
import project.bee.notex.ui.notelist.*

@Module
class NotesModule(val activity: Activity) {
    @Provides
    fun provideActivity() = activity

    @NotesScope
    @Provides
    fun provideNotesPresenter(useCase: NotesUseCase,
                              @IoThread ioScheduler: Scheduler,
                              @MainThread NotesScheduler: Scheduler): NotesContract.Presenter =
            NotesPresenterImpl(useCase, ioScheduler, NotesScheduler)

    @NotesScope
    @Provides
    fun provideNotesUseCase(repo: NotesRepo): NotesUseCase = NotesUseCaseImpl(repo)

    @NotesScope
    @Provides
    fun provideNotesRepo(database: NoteDatabaseImpl): NotesRepo = NotesRepoImpl(database)
}