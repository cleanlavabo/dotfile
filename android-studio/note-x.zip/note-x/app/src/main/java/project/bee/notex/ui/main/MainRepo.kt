package project.bee.notex.ui.main

import io.reactivex.Single
import project.bee.notex.data.DataGenerator
import project.bee.notex.database.NoteDatabaseImpl

interface MainRepo {
    fun getCategories(): Single<MutableList<NotebookViewModel>>

}

class MainRepoImpl(val database: NoteDatabaseImpl) : MainRepo {
    override fun getCategories(): Single<MutableList<NotebookViewModel>> {
        return Single.fromCallable {
            val notebooks = DataGenerator.generateNotebooks()
            database.notebookDao().addNotebook(notebooks[0].notebook)
            notebooks
        }
    }
}