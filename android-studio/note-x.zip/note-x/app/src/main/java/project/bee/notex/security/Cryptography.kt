package project.bee.notex.security

import org.bouncycastle.crypto.engines.ChaChaEngine
import org.bouncycastle.crypto.params.KeyParameter
import org.bouncycastle.crypto.params.ParametersWithIV
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream


object Cryptography {
    const val KEY_CHACHA_20_MAX_BYTE = 32 // 256 bit
    const val IV_CHACHA_20_MAX_BYTE = 8 // 64 bit

    fun encodeChaCha(input: String, key: ByteArray, iv: ByteArray): ByteArray {
        val inputStream = input.byteInputStream()
        val outputStream = ByteArrayOutputStream()
        encodeChaCha(inputStream, outputStream, key, iv)
        return outputStream.toByteArray()
    }

    fun decodeChaCha(input: ByteArray, key: ByteArray, iv: ByteArray): ByteArray {
        val isEnc = input.inputStream()
        val osEnc = ByteArrayOutputStream()
        decodeChaCha(isEnc, osEnc, key, iv)
        return osEnc.toByteArray()
    }

    fun encodeChaCha(inputStream: InputStream, outputStream: OutputStream, key: ByteArray,
                     iv: ByteArray) {
        doChaCha(true, inputStream, outputStream, key, iv)
    }

    fun decodeChaCha(inputStream: InputStream, outputStream: OutputStream, key: ByteArray,
                     iv: ByteArray) {
        doChaCha(false, inputStream, outputStream, key, iv)
    }

    private fun doChaCha(encrypt: Boolean, inputStream: InputStream, outputStream: OutputStream,
                         key: ByteArray, iv: ByteArray) {
        val cp = KeyParameter(key)
        val params = ParametersWithIV(cp, iv)
        val engine = ChaChaEngine()
        engine.init(encrypt, params)

        val input = ByteArray(8192)
        val output = ByteArray(8192)
        var len = 0
        while (len.let { len = inputStream.read(input); len != -1 }) {
            len = engine.processBytes(input, 0, len, output, 0)
            outputStream.write(output, 0, len)
        }
    }

    fun generateChachaKey(): ByteArray {
        return GeneratorUtil.generateRandomByte(32)
    }

    fun generateChachaIv(): ByteArray {
        return GeneratorUtil.generateRandomByte(8)
    }
}