# 100 days of noteX

**Day 1**

- Finnaly figure out when the `RecyclerView` has finished laying down the child views. By using `ListAdapter` + `DiffUtils` + `submitList(items, **callback**)`

```
adapter.submitList(items, { callback-> 
	// views have been updated
	// do something here... scrollTo() ...
})
```
Btw, `submitList` has 2 parts, differency calculation (should be called on `computation()`) and callback (**requires** `MainThread`)

- Obseravable can be converted to Completable by using 
	* `Observable.just(1).ignoreElements()`
	* `Observable.just(1).flatmapCompletable()` or `concatCompletable()`

But `flatmap` doesn't ensure the result will emit the result to `subscribe()`. In order to make it, explicitly calls `Completable.completed()`
	
- Room Database can be used with [`@Query`](https://developer.android.com/reference/android/arch/persistence/room/Query), [`@RawQuery`](https://developer.android.com/reference/android/arch/persistence/room/RawQuery)
	* parameters of funtion can be used as `:param`
	* Android studio will auto suggests for the properties of entities (tables)


```
@Query("SELECT * from Note WHERE notebook_uuid = :notebookId ORDER BY updated_at DESC")
fun getAll(notebookId: String): Observable<List<Note>>
```

**Day 2**

-  `EditNoteActivity` takes control over 3 actions: Add, edit and delete. The logic behind is a bit complicated, so I decided to convert it to clean arch in order to write test and maintain.

- By using `@Insert(onConflict = REPLACE)` I can easily achieve something like upsert in `SQL` (insert or update).

- Enum class in `Java/Kotlin` is serialized by default. that's why you can put it inside a **bundle** (or argument) of `Intent/Fragment`. (Avoid using ordinary because of it's hard to handle a state base on the `No. number` of enum properties).


```
// put
intent.putExtra("key", yourEnum);

// get
yourEnum = (YourEnum) intent.getSerializableExtra("key");
```

