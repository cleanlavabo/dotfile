package project.bee.notex.ui.notelist

import project.bee.notex.database.entity.Note

private const val DEFAULT_CONTENT = "No additional text"
private const val DEFAULT_TITLE = "New note"
private const val MAX_LENGTH = 50

data class NoteViewModel(val note: Note = Note("", "")) {
    val isEmpty = note.content.isEmpty()

    val title = if (note.content.isEmpty()) DEFAULT_TITLE else firstLine

    val content: String
        get() {
            return if (note.content.isEmpty()) {
                DEFAULT_CONTENT
            } else {
                val title = title
                val titleStartAt = note.content.indexOf(title)
                val secondPart = note.content.substring(titleStartAt + title.length, note.content.length)
                val result = joinLines(secondPart)
                return if (result.isEmpty()) DEFAULT_CONTENT else result
            }
        }

    private fun joinLines(text: String): String {
        var sum = 0
        return text.split("\n")
                .takeIf { it.isNotEmpty() }
                ?.takeWhile { sum += it.length; sum < MAX_LENGTH }
                ?.filter { it.isNotBlank() }
                ?.joinToString(separator = " ") ?: ""
    }

    val firstLine: String
        get() {
            val data = note.content.split("\n")
            return data.firstOrNull { it.isNotBlank() } ?: ""
        }
}