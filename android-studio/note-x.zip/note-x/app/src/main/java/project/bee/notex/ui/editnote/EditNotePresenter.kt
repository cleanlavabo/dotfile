package project.bee.notex.ui.editnote

import io.reactivex.Scheduler
import project.bee.notex.database.entity.Note

class EditNotePresenterImpl(val useCase: EditNoteUseCase,
                            val io: Scheduler,
                            val main: Scheduler) : EditNoteContract.Presenter {
    private val subscription = CompositeDisposable()
    private lateinit var view: EditNoteContract.View

    override fun destroy() {
        subscription.dispose()
    }

    override fun create() {
        view.setupViews()
        view.getBundle()
        loadData(view.note())
        setupEvents()
    }

    override fun attachView(view: EditNoteContract.View) {
        this.view = view
    }

    override fun loadData(note: Note?) {
        note?.let {
            view.setupContent(it)
        }

        if (note?.content?.isNotEmpty() == true) {
            view.hideSoftKey()
        } else {
            view.showSoftKey()
        }
    }

    override fun setupEvents() {
        subscription.add(view.editTextClicks()
                .observeOn(main)
                .subscribe({
                    view.showCursor()
                }, {

                }))
    }

    override fun deleteNote() {
        when (view.action()) {
            NoteAction.EDIT -> {
//                subscription.add(useCase.deleteNote(view.note())
//                        .subscribeOn()
//                        .subscribe()

                )
            }

            NoteAction.ADD -> {
                view.finish()
            }
        }
    }

    //
//    private fun updateNoteAndSetResult(isDeleted: Boolean) {
//        val isContentChanged = isContentChange()
//        updateNote(isContentChanged)
//        setResult(isDeleted, isContentChanged)
//    }
//
//    private fun updateNote(contentChanged: Boolean) {
//        if (contentChanged) {
//            note.updatedAt = System.currentTimeMillis()
//            note.content = etContent.text.toString()
//        }
//    }
//
}