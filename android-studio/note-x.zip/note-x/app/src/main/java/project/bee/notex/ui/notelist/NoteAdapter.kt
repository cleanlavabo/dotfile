package project.bee.notex.ui.notelist

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jakewharton.rxbinding2.view.clicks
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.functions.Consumer
import io.reactivex.subjects.PublishSubject
import kotlinx.android.synthetic.main.item_note.view.*
import project.bee.notex.R
import project.bee.notex.database.entity.Note
import project.bee.notex.util.DateTimeUtil
import project.bee.notex.util.RxUtil

class NoteViewModelDiffCallback : DiffUtil.ItemCallback<NoteViewModel>() {
    override fun areItemsTheSame(oldItem: NoteViewModel, newItem: NoteViewModel): Boolean {
        return oldItem.note.id != newItem.note.id
    }

    override fun areContentsTheSame(oldItem: NoteViewModel, newItem: NoteViewModel): Boolean {
        return oldItem.note == newItem.note
    }
}

class NoteAdapter(val context: Context) : ListAdapter<NoteViewModel, NoteAdapter.ViewHolder>(NoteViewModelDiffCallback()) {
    val noteClickSubject: PublishSubject<Note> = PublishSubject.create<Note>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context)
                .inflate(R.layout.item_note, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val viewModel = getItem(position)
        holder.setup(context, viewModel)
        noteClicks(holder, viewModel)
    }

    private fun noteClicks(holder: ViewHolder, note: NoteViewModel) {
        holder.disposable?.dispose()

        holder.disposable = holder.itemView.clicks()
                .compose(RxUtil.withShortThrottleFirst())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(Consumer {
                    noteClickSubject.onNext(note.note)
                }, RxUtil.emptyErrorConsumer())
    }

    class ViewHolder(private val view: View) : RecyclerView.ViewHolder(view) {
        var disposable: Disposable? = null

        fun setup(context: Context, viewModel: NoteViewModel) {
            view.tvTitle.text = viewModel.title
            view.tvContent.text = viewModel.content
            view.tvUpdatedAt.text = DateTimeUtil.getDateTime(context, viewModel.note.updatedAt)
        }
    }
}
