package project.bee.notex.ui.main

import io.reactivex.Scheduler
import io.reactivex.disposables.CompositeDisposable
import project.bee.notex.util.RxUtil
import timber.log.Timber

class MainPresenterImpl(val useCase: MainUseCase,
                        val io: Scheduler,
                        val main: Scheduler) : MainContract.Presenter {
    private lateinit var view: MainContract.View
    private val subscription = CompositeDisposable()

    override fun attachView(view: MainContract.View) {
        this.view = view
    }

    override fun create() {
        view.setupViews()
        loadData()
        setupEvents()
    }

    override fun loadData() {
        subscription.add(useCase.getCategories()
                .subscribeOn(io)
                .observeOn(main)
                .subscribe({
                    view.setCategories(it)
                    if (it.size > 0) {
                        view.replaceFrag(it[0])
                    }
                    categoryClicks()
                }, {
                    handleError(it)
                }))
    }

    override fun setupEvents() {
        categoryListClicks()
        settingClicks()
        editCategoryClicks()
        deleteCategoryClicks()
    }

    override fun categoryClicks() {
        subscription.add(view.categoryClicks()
                .compose(RxUtil.withShortThrottleFirst())
                .observeOn(main)
                .subscribe({
                    view.dismissCategoryDialog()
                    view.replaceFrag(it)
                }, {

                }))
    }

    override fun settingClicks() {
        subscription.add(view.settingClicks()
                .compose(RxUtil.withShortThrottleFirst())
                .observeOn(main)
                .subscribe({
                    view.showSettingDialog()
                }, {

                }))
    }

    override fun deleteCategoryClicks() {
        subscription.add(view.deleteCategoryClicks()
                .compose(RxUtil.withShortThrottleFirst())
                .observeOn(main)
                .subscribe({
                    view.dismissSettingDialog()
                }, {

                }))
    }

    override fun editCategoryClicks() {
        subscription.add(view.editCategoryClicks()
                .compose(RxUtil.withShortThrottleFirst())
                .observeOn(main)
                .subscribe({
                    view.dismissCategoryDialog()
                }, {

                }))
    }

    override fun categoryListClicks() {
        subscription.add(view.categoriesClicks()
                .compose(RxUtil.withShortThrottleFirst())
                .observeOn(main)
                .subscribe({
                    view.showCategoryDialog()
                }, {

                }))
    }

    override fun destroy() {
        subscription.dispose()
    }

    override fun handleError(throwable: Throwable) {
        Timber.e(throwable)
    }
}