package project.bee.notex.ui.main

import io.reactivex.Single

interface MainUseCase {
    fun getCategories(): Single<MutableList<NotebookViewModel>>
}

class MainUseCaseImpl(val repo: MainRepo) : MainUseCase {
    override fun getCategories(): Single<MutableList<NotebookViewModel>> {
        return repo.getCategories()
    }
}