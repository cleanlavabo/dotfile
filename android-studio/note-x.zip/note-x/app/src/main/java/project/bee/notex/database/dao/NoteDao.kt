package project.bee.notex.database.dao

import androidx.room.*
import androidx.room.OnConflictStrategy.REPLACE
import io.reactivex.Observable
import project.bee.notex.database.entity.Note

@Dao
interface NoteDao {
    @Query("SELECT * from Note WHERE notebook_uuid = :notebookId ORDER BY updated_at DESC")
    fun getAll(notebookId: String): Observable<List<Note>>

    @Insert(onConflict = REPLACE)
    fun addNote(note: Note): Long?

    @Update
    fun editNote(note: Note)

    @Delete
    fun removeNote(vararg note: Note)
}