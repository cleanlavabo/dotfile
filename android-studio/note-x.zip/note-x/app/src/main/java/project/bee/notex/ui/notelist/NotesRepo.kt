package project.bee.notex.ui.notelist

import io.reactivex.Observable
import project.bee.notex.database.NoteDatabaseImpl
import project.bee.notex.database.entity.Note

interface NotesRepo {
    fun getNotes(notebookId: String): Observable<List<Note>>
    fun addNote(note: Note)
}

class NotesRepoImpl(val database: NoteDatabaseImpl) : NotesRepo {
    override fun addNote(note: Note) {
        database.noteDao().addNote(note)
    }

    override fun getNotes(notebookId: String): Observable<List<Note>> {
        return database.noteDao().getAll(notebookId)
    }
}