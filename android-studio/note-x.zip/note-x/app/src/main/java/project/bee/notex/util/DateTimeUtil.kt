package project.bee.notex.util

import android.content.Context
import android.text.format.DateUtils
import android.text.format.Time
import project.bee.notex.R
import java.text.SimpleDateFormat
import java.util.*

/**
 * Using @param now because there is noway to stub System.currentTimeMillis
 */
object DateTimeUtil {
    fun getDateTime(context: Context, time: Long) = getDateTime(context, time, System.currentTimeMillis())

    /**
     * Less than 1 minute: "just now"
     * Less than 1 hour: "X minutes ago"
     * Less than 1 day: "X hour ago"
     * Less than 2 days: "Yesterday"
     * Less than 7 days (1 week): “Monday, Tuesday, … , Sunday”
     * Any time later than 1 week: "dd MMM, yyyy" (example: 03 Mar, 2018)
     */
    fun getDateTime(context: Context, time: Long, now: Long): String {
        val diffMs = (now - time).toDouble()
        val diffSeconds = (diffMs / 1000)
        val diffMinutes = (diffSeconds / 60)
        val diffHours = diffMinutes / 60
        val diffDays = diffHours / 24

        return when {
            diffDays >= 7F -> getFullDate(time)
            diffDays >= 2F -> getDayOfWeek(time)
            diffMinutes >= 1F -> {
                if (isToday(time, now)) getRelativeTime(time, now)
                else context.resources.getString(R.string.content_yesterday)
            }
            else -> context.resources.getString(R.string.content_just_now)
        }
    }

    private fun isToday(timeInMilliseconds: Long, now: Long): Boolean {
        val time = Time()
        time.set(timeInMilliseconds)

//        System.out.print(String.format("%s %s %s", time.hour, time.minute, time.second))
//        System.out.println()

        val thenYear = time.year
        val thenMonth = time.month
        val thenMonthDay = time.monthDay

        time.set(now)

//        System.out.print(String.format("%s %s %s", time.hour, time.minute, time.second))
        return (thenYear == time.year
                && thenMonth == time.month
                && thenMonthDay == time.monthDay)
    }

    private fun getRelativeTime(time: Long, now: Long) = DateUtils.getRelativeTimeSpanString(time, now, DateUtils.SECOND_IN_MILLIS).toString()

    private fun getRelativeTime(time: Long) = getRelativeTime(time, System.currentTimeMillis())

    // 03 Mar, 2018
    private fun getFullDate(time: Long) = SimpleDateFormat("dd MMM, yyyy", Locale.US).format(Date(time))

    // Monday, Tuesday, Wednesday..
    private fun getDayOfWeek(time: Long) = SimpleDateFormat("EEEE", Locale.US).format(Date(time))
}