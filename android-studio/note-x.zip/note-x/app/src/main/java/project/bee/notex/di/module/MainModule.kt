package project.bee.notex.di.module

import android.app.Activity
import dagger.Module
import dagger.Provides
import io.reactivex.Scheduler
import project.bee.notex.database.NoteDatabaseImpl
import project.bee.notex.di.scope.IoThread
import project.bee.notex.di.scope.MainScope
import project.bee.notex.di.scope.MainThread
import project.bee.notex.ui.main.*

@Module
class MainModule(val activity: Activity) {
    @Provides
    fun provideActivity() = activity

    @MainScope
    @Provides
    fun provideMainPresenter(useCase: MainUseCase,
                             @IoThread ioScheduler: Scheduler,
                             @MainThread mainScheduler: Scheduler): MainContract.Presenter =
            MainPresenterImpl(useCase, ioScheduler, mainScheduler)

    @MainScope
    @Provides
    fun provideMainUseCase(repo: MainRepo): MainUseCase = MainUseCaseImpl(repo)

    @MainScope
    @Provides
    fun provideMainRepo(database: NoteDatabaseImpl): MainRepo = MainRepoImpl(database)
}