package project.bee.notex.util

import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment


/**
 * TODO there is no way to stub System.currentTimeMillis at this time
 * Please go to DateTimeUtil.class then change the function above to this value: 1526832000000
 */
@RunWith(RobolectricTestRunner::class)
class DateTimeUtilTest {
    private val context = RuntimeEnvironment.application.applicationContext
    // Sunday, May 20, 2018 11:00:00 PM GMT+07:00
    // Sunday, May 20, 2018 4:00:00 PM (GMT 00:00)
    private val currentTimeMillis = 1526832000000

    companion object {
        const val oneMinute = 1 * 60 * 1000
    }

    @Before
    fun setUp() {

    }

    @Test
    fun givenTimestamp_whenTimeIsGreaterThan1Week_returnAsFullDate_thenCorrect() {
        val sevenDays = 7 * 24 * 60 * 60 * 1000
        var date = DateTimeUtil.getDateTime(context, currentTimeMillis - sevenDays, currentTimeMillis)
        assertEquals("13 May, 2018", date)

        val eightDays = 8 * 24 * 60 * 60 * 1000
        date = DateTimeUtil.getDateTime(context, currentTimeMillis - eightDays, currentTimeMillis)
        assertEquals("12 May, 2018", date)
    }

    @Test
    fun givenTimestamp_whenTimeIsGreaterThan2Days_returnAsDayOfWeek_thenCorrect() {
        val twoDays = 2 * 24 * 60 * 60 * 1000
        val date = DateTimeUtil.getDateTime(context, currentTimeMillis - twoDays, currentTimeMillis)
        assertEquals("Friday", date)

        val sevenDays = 7 * 24 * 60 * 60 * 1000 - oneMinute
        val date2 = DateTimeUtil.getDateTime(context, currentTimeMillis - sevenDays, currentTimeMillis)
        assertEquals("Sunday", date2)
    }

    @Test
    fun givenTimestamp_whenTimeGreaterThan1Day_returnAsYesterday_thenCorrect() {
        val twoDays = 48 * 60 * 60 * 1000 - oneMinute
        val date = DateTimeUtil.getDateTime(context, currentTimeMillis - twoDays, currentTimeMillis)
        assertEquals("Yesterday", date)
    }

    @Test
    fun givenTimestamp_whenTimeSmallerThan1DayButStillIsYesterday_returnAsYesterday_thenCorrect() {
        val twentyThreeHours = 23 * 60 * 60 * 1000 + oneMinute //
        val date = DateTimeUtil.getDateTime(context, currentTimeMillis - twentyThreeHours, currentTimeMillis)
        assertEquals("Yesterday", date)
    }

    @Test
    fun givenTimestamp_whenTimeIsSmallerThan1Day_returnAsRelativeTimestamp_thenCorrect() {
        val twentyThreeHours = 23 * 60 * 60 * 1000
        val date = DateTimeUtil.getDateTime(context, currentTimeMillis - twentyThreeHours, currentTimeMillis)
        assertEquals("23 hours ago", date)
    }

    @Test
    fun givenTimestamp_whenTimeGreaterThan60MinutesAndSmallerThan1DayReturnAsXHoursAgo_thenWorks() {
        val sixHours = 6 * 60 * 60 * 1000
        val date = DateTimeUtil.getDateTime(context, currentTimeMillis - sixHours, currentTimeMillis)
        assertEquals("6 hours ago", date)
    }

    @Test
    fun givenTimestamp_whenTimeGreaterThan1MinuteAndSmallerThan60MinutesReturnAsXMinutesAgo_thenWorks() {
        val tenMinutes = 10 * 60 * 1000
        val date = DateTimeUtil.getDateTime(context, currentTimeMillis - tenMinutes, currentTimeMillis)
        assertEquals("10 minutes ago", date)
    }

    @Test
    fun givenTimestamp_whenTimeSmallerThan60SecondsReturnAsJustNow_thenCorrect() {
        val tenSeconds = 10 * 1000
        val date = DateTimeUtil.getDateTime(context, currentTimeMillis - tenSeconds, currentTimeMillis)
        assertEquals("just now", date)
    }
}