package project.bee.notex.data

import project.bee.notex.database.entity.Note
import project.bee.notex.ui.main.NotebookViewModel

object DataGenerator {
    fun generateNotebooks(): MutableList<NotebookViewModel> {
        return mutableListOf(
                NotebookViewModel("All notes", true),
                NotebookViewModel("This is notebook 2"),
                NotebookViewModel("This is notebook 3"),
                NotebookViewModel("This is notebook 4"),
                NotebookViewModel("This is notebook 5"))
    }

    fun generateNote(notebookId: String): Note {
        return Note("This is the new note ${System.currentTimeMillis()}", notebookId)
    }
}