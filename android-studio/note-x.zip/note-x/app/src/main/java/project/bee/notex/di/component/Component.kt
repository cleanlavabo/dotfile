package project.bee.notex.di.component

import dagger.Subcomponent
import project.bee.notex.di.module.EditNoteModule
import project.bee.notex.di.module.MainModule
import project.bee.notex.di.module.NotesModule
import project.bee.notex.di.scope.EditNoteScope
import project.bee.notex.di.scope.MainScope
import project.bee.notex.di.scope.NotesScope
import project.bee.notex.ui.main.MainActivity
import project.bee.notex.ui.notelist.NotesFragment

@MainScope
@Subcomponent(modules = [MainModule::class])
interface MainComponent {
    fun inject(mainActivity: MainActivity)
}

@NotesScope
@Subcomponent(modules = [NotesModule::class])
interface NotesComponent {
    fun inject(notesFragment: NotesFragment)
}

@EditNoteScope
@Subcomponent(modules = [EditNoteModule::class])
interface EditNoteComponent {
    fun inject(notesFragment: NotesFragment)
}