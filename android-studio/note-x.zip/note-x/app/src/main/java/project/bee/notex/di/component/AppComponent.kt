package project.bee.notex.di.component

import dagger.Component
import project.bee.notex.App
import project.bee.notex.di.module.AppModule
import project.bee.notex.di.module.MainModule
import project.bee.notex.di.module.NotesModule

@Component(modules = [AppModule::class])
interface AppComponent {
    fun inject(app: App)

    fun newMainComponent(mainModule: MainModule): MainComponent
    fun newNotesComponent(notesModule: NotesModule): NotesComponent
}