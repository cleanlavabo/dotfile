package project.bee.notex.security

import org.junit.Test

import org.junit.Assert.*
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.charset.StandardCharsets

class CryptographyTest {

    @Test
    fun givenNotEmptyFile_whenFileIsNotNullAndSizeBiggerThanZero_thenCorrect() {
        val stream = getFileFromPath(this, "book.pdf")
        val n = stream.available()
        val bytes = ByteArray(n)
        stream.read(bytes, 0, n)
        assertTrue(bytes.isNotEmpty())
    }

    @Test
    fun givenZeroMegabyte_whenGenerateStringWorks_thenCorrect() {
        val text = GeneratorUtil.createString(0)
        assertEquals(0, text.toByteArray().size)
    }

    @Test
    fun givenAnInteger_whenGenerateStringWorks_thenCorrect() {
        val text = GeneratorUtil.createString(100)
        assertEquals(100 * 1024 / 2, text.toByteArray().size)
    }

    @Test
    fun givenFile_whenEncodeAndDecodeWorks_thenCorrect() {
        val stream = getFileFromPath(this, "citylots.json")
        val n = stream.available()
        val bytes = ByteArray(n)
        stream.read(bytes, 0, n)

        val key = Cryptography.generateChachaKey()
        val iv = Cryptography.generateChachaIv()

        //encode
        val inputStream = ByteArrayInputStream(bytes)
        val outputStream = ByteArrayOutputStream()
        Cryptography.encodeChaCha(inputStream, outputStream, key, iv)
        val encoded = outputStream.toByteArray()

        // decode
        val inputStreamDecoded = ByteArrayInputStream(encoded)
        val outputStreamDecoded = ByteArrayOutputStream()
        Cryptography.decodeChaCha(inputStreamDecoded, outputStreamDecoded, key, iv)
        val decoded = outputStreamDecoded.toByteArray()

        assertEquals(String(bytes, StandardCharsets.UTF_8), String(decoded, StandardCharsets.UTF_8))
    }

    @Test
    fun givenString_whenEncodeAndDecodeWorks_thenCorrect() {
        val key = Cryptography.generateChachaKey()
        val iv = Cryptography.generateChachaIv()

        val inputString = GeneratorUtil.createString(100)
        val encodedString = Cryptography.encodeChaCha(inputString, key, iv)
        val decodedString = Cryptography.decodeChaCha(encodedString, key, iv)
        assertEquals(inputString, String(decodedString, StandardCharsets.UTF_8))
    }

    private fun getFileFromPath(obj: Any, fileName: String): InputStream {
        val classLoader = obj.javaClass.classLoader
        return classLoader.getResourceAsStream(fileName)
    }
}