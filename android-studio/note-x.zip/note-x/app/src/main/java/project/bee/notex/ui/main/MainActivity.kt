package project.bee.notex.ui.main

import android.app.Dialog
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.jakewharton.rxbinding2.view.RxView
import io.reactivex.Observable
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.bottom_sheet_category.view.*
import kotlinx.android.synthetic.main.bottom_sheet_setting.view.*
import project.bee.notex.App
import project.bee.notex.R
import project.bee.notex.di.module.MainModule
import project.bee.notex.ui.notelist.NotesFragment
import javax.inject.Inject

class MainActivity : AppCompatActivity(), MainContract.View {
    private var notebookAdapter: NotebookAdapter? = null
    private lateinit var bottomSheetCategory: View
    private lateinit var bottomSheetSetting: View
    private lateinit var categoryDialog: Dialog
    private lateinit var settingDialog: Dialog
    private lateinit var currentFragment: NotesFragment

    @Inject
    lateinit var presenter: MainContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        di()
        presenter.attachView(this)
        presenter.create()
    }

    private fun di() {
        App.instance.appComponent
                .newMainComponent(MainModule(this))
                .inject(this)
    }

    override fun setupViews() {
        setupSettingSheet()
        setupCategorySheet()
    }

    override fun setCategories(notebooks: MutableList<NotebookViewModel>) {
        notebookAdapter = NotebookAdapter(this@MainActivity, notebooks)
        bottomSheetCategory.rvCategory.adapter = notebookAdapter
    }

    override fun replaceFrag(notebook: NotebookViewModel) {
        replaceFragment(notebook)
    }

    private fun setupSettingSheet() {
        bottomSheetSetting = layoutInflater.inflate(R.layout.bottom_sheet_setting, root, false)
        settingDialog = BottomSheetDialog(this)
        settingDialog.setContentView(bottomSheetSetting)
    }

    private fun setupCategorySheet() {
        bottomSheetCategory = layoutInflater.inflate(R.layout.bottom_sheet_category, root, false)
        bottomSheetCategory.rvCategory?.apply {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
        }

        categoryDialog = BottomSheetDialog(this)
        categoryDialog.setContentView(bottomSheetCategory)
    }

    private fun replaceFragment(notebook: NotebookViewModel) {
        currentFragment = NotesFragment.newInstance(notebook.notebook)
        supportFragmentManager.beginTransaction()
                .apply {
                    replace(R.id.container, currentFragment)
                    commit()
                }
    }

    override fun showSettingDialog() {
        settingDialog.show()
    }

    override fun dismissSettingDialog() {
        settingDialog.dismiss()
    }

    override fun showCategoryDialog() {
        categoryDialog.show()
    }

    override fun dismissCategoryDialog() {
        categoryDialog.dismiss()
    }

    override fun categoryClicks(): Observable<NotebookViewModel> {
        return notebookAdapter?.notebookClick ?: Observable.just(NotebookViewModel())
    }

    override fun settingClicks(): Observable<Any> {
        return RxView.clicks(ivSetting)
    }

    override fun categoriesClicks(): Observable<Any> {
        return RxView.clicks(ivCategory)
    }

    override fun deleteCategoryClicks(): Observable<Any> {
        return RxView.clicks(bottomSheetSetting.tvDeleteCategory)
    }

    override fun editCategoryClicks(): Observable<Any> {
        return RxView.clicks(bottomSheetSetting.tvEditCategory)
    }

    override fun onDestroy() {
        presenter.destroy()
        super.onDestroy()
    }
}
