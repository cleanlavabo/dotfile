package project.bee.notex.ui.editnote

import io.reactivex.Observable
import project.bee.notex.database.entity.Note

interface EditNoteContract {
    interface View {
        fun setupViews()
        fun getBundle()
        fun note(): Note
        fun notebookId(): String
        fun action(): NoteAction
        fun setupContent(it: Note)
        fun showSoftKey()
        fun hideSoftKey()
        fun editTextClicks(): Observable<Unit>
        fun showCursor()
        fun content(): String
        fun finish()
    }

    interface Presenter {
        fun destroy()
        fun create()
        fun attachView(view: View)
        fun loadData(note: Note?)
        fun setupEvents()
        fun deleteNote()
    }
}