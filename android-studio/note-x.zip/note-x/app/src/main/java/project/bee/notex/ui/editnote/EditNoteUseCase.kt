package project.bee.notex.ui.editnote

import android.util.Log
import io.reactivex.Completable
import io.reactivex.Single
import project.bee.notex.database.entity.Note

interface EditNoteUseCase {
    fun deleteNote(note: Note):Completable

}

class EditNoteUseCaseImpl(val repo: EditNoteRepo) : EditNoteUseCase {
    override fun deleteNote(note: Note): Completable {
        return repo.deleteNote(note)
    }
}