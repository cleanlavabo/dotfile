package project.bee.notex.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import project.bee.notex.database.NoteDatabaseImpl.Companion.VERSION
import project.bee.notex.database.dao.NoteDao
import project.bee.notex.database.dao.NotebookDao
import project.bee.notex.database.entity.Note
import project.bee.notex.database.entity.Notebook

object NoteDatabase {
    fun instance(context: Context) = Room.databaseBuilder(context,
            NoteDatabaseImpl::class.java, NoteDatabaseImpl.DATABASE_NAME)
            .build()
}

@Database(entities = [Notebook::class, Note::class], version = VERSION, exportSchema = false)
abstract class NoteDatabaseImpl : RoomDatabase() {
    companion object {
        const val VERSION = 1
        const val DATABASE_NAME = "note-database"
    }

    abstract fun noteDao(): NoteDao
    abstract fun notebookDao(): NotebookDao
}