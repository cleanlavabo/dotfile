package project.bee.notex.ui.main

import project.bee.notex.database.entity.Notebook

data class NotebookViewModel(val notebook: Notebook = Notebook(""),
                             var isSelected: Boolean = false) {
    constructor(content: String, isSelected: Boolean = false) : this(Notebook(content), isSelected)
}