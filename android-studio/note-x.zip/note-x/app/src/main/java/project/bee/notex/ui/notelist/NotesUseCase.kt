package project.bee.notex.ui.notelist

import io.reactivex.Observable
import project.bee.notex.database.entity.Note

interface NotesUseCase {
    fun getNotes(notebookId: String): Observable<List<Note>>
    fun addNote(note: Note)
}

class NotesUseCaseImpl(private val repo: NotesRepo) : NotesUseCase {
    override fun addNote(note: Note) {
        repo.addNote(note)
    }

    override fun getNotes(notebookId: String): Observable<List<Note>> {
        return repo.getNotes(notebookId)
    }
}