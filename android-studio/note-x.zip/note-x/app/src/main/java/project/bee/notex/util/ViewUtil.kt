package project.bee.notex.util

import android.annotation.TargetApi
import android.app.Activity
import android.content.Context
import android.os.Build
import android.view.View
import android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
import android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar
import project.bee.notex.R


object ViewUtil {
    private const val SNACK_BAR_DURATION = 5000

    fun setSoftKeyVisible(activity: Activity, visible: Boolean) {
        val window = activity.window
        val mode = if (visible) SOFT_INPUT_STATE_VISIBLE else SOFT_INPUT_STATE_HIDDEN
        window?.setSoftInputMode(mode)
    }

    fun showUndoBar(context: Context?, wrapperLayout: View, content: CharSequence, callback: View.OnClickListener) {
        setupSnackBarThenShow(context,
                Snackbar.make(wrapperLayout, content, SNACK_BAR_DURATION)
                        .setAction(context?.applicationContext?.getString(R.string.content_undo),
                                callback)
                        .setActionTextColor(ContextCompat.getColor(context!!, R.color.colorYellow)))
    }

    @TargetApi(Build.VERSION_CODES.O)
    private fun setupSnackBarThenShow(context: Context?, snackBar: Snackbar) {
        val snackBarView = snackBar.view
        val tvMessage = snackBarView.findViewById(com.google.android.material.R.id.snackbar_text) as TextView
        val tvAction = snackBarView.findViewById(com.google.android.material.R.id.snackbar_action) as TextView
        with(tvMessage)
        {
            setSingleLine()
            typeface = context?.applicationContext?.resources?.getFont(R.font.font_regular)
        }

        with(tvAction)
        {
            typeface = context?.applicationContext?.resources?.getFont(R.font.font_bold)
        }

        snackBar.show()
    }
}