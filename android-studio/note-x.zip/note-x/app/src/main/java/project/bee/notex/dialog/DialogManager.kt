package project.bee.notex.dialog

import android.content.Context
import androidx.appcompat.app.AlertDialog
import project.bee.notex.BuildConfig
import project.bee.notex.R


class DialogManager {
    companion object {
        fun showVersionDialog(context: Context?) {
            context?.let {
                AlertDialog.Builder(it)
                        .setTitle(R.string.content_version)
                        .setMessage(BuildConfig.VERSION_NAME)
                        .setPositiveButton(android.R.string.yes) { dialog, _ ->
                            dialog.dismiss()
                        }
                        .show()
            }
        }
    }
}