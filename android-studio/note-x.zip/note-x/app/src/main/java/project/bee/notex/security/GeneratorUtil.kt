package project.bee.notex.security

import android.os.Build
import java.security.SecureRandom
import java.util.*

object GeneratorUtil {
    fun createString(mbSize: Int): String {
        if (mbSize == 0) {
            return ""
        }

        val r = Random()
        // 1 char = 2 bytes in java
        val byteSize = mbSize * 1024 / 2

        val sb = StringBuilder(byteSize)
        for (i in 0 until byteSize) {
            val c = (r.nextInt(26) + 'a'.toInt()).toChar()
            sb.append(c)
        }

        return sb.toString()
    }

    fun generateRandomByte(byte: Int): ByteArray {
        val result = ByteArray(byte)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            SecureRandom.getInstanceStrong().nextBytes(result)
        } else {
            val random = Random()
            random.nextBytes(result)
        }

        return result
    }
}