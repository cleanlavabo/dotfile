package project.bee.notex.ui.editnote

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.jakewharton.rxbinding2.view.clicks
import io.reactivex.Observable
import kotlinx.android.synthetic.main.activity_edit_note.*
import project.bee.notex.R
import project.bee.notex.database.entity.Note
import project.bee.notex.util.DateTimeUtil
import project.bee.notex.util.ViewUtil
import javax.inject.Inject

enum class NoteAction {
    EDIT,
    ADD
}

class EditNoteActivity : AppCompatActivity(), EditNoteContract.View {
    @Inject
    lateinit var presenter: EditNoteContract.Presenter

    var note: Note? = null
    var notebookId: String? = null
    val action: NoteAction by lazy {
        intent?.extras?.getSerializable(ARG_ACTION) as NoteAction
    }

    override fun note(): Note {
        return note ?: Note("", "")
    }

    override fun notebookId(): String {
        return notebookId ?: ""
    }

    override fun action(): NoteAction {
        return action
    }

    override fun onDestroy() {
        presenter.destroy()
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_note)
        presenter.attachView(this)
        presenter.create()
        getBundle()
        setupViews()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_edit_note, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun getBundle() {
        when (action) {
            NoteAction.ADD -> {
                notebookId = intent?.extras?.getString(ARG_NOTEBOOK_ID)
            }

            NoteAction.EDIT -> {
                note = intent?.extras?.getParcelable(ARG_NOTE)
            }
        }
    }

    override fun setupViews() {
        setSupportActionBar(toolbar)
        supportActionBar?.title = ""
        scrollView.isSmoothScrollingEnabled = true
    }

    override fun setupContent(it: Note) {
        tvUpdatedAt.text = DateTimeUtil.getDateTime(this, note?.updatedAt ?: 0)
        etContent.setText(note?.content ?: "")
    }

    override fun showSoftKey() {
        etContent.isCursorVisible = true
        ViewUtil.setSoftKeyVisible(this, true)
        etContent.requestFocus()
    }

    override fun hideSoftKey() {
        ViewUtil.setSoftKeyVisible(this, false)
    }

    override fun editTextClicks(): Observable<Unit> {
        return etContent.clicks()
    }

    override fun showCursor() {
        etContent.isCursorVisible = true
    }


    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.action_delete_note -> {
                presenter.deleteNote()
            }
            else -> {
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun content(): String = etContent.text.toString()

    companion object {
        const val ARG_NOTE = "arg-note"
        const val ARG_NOTEBOOK_ID = "arg-notebook-id"
        const val ARG_ACTION = "arg-action"

        fun newEditNoteIntent(context: Context, note: Note) =
                Intent(context, EditNoteActivity::class.java).apply {
                    putExtra(ARG_NOTE, note)
                    putExtra(ARG_ACTION, NoteAction.EDIT)
                }

        fun newAddNoteIntent(context: Context, notebookId: String) =
                Intent(context, EditNoteActivity::class.java).apply {
                    putExtra(ARG_NOTEBOOK_ID, notebookId)
                    putExtra(ARG_ACTION, NoteAction.ADD)
                }
    }
}
