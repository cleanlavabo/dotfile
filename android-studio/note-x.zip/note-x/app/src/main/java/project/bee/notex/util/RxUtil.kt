package project.bee.notex.util

import io.reactivex.ObservableTransformer
import io.reactivex.Scheduler
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers
import project.bee.notex.BuildConfig
import java.util.concurrent.TimeUnit

object RxUtil {
    fun disposeDisposable(target: Disposable?) {
        if (target != null && !target.isDisposed) {
            target.dispose()
        }
    }

    fun <R> withShortThrottleFirst(): ObservableTransformer<R, R> {
        return ObservableTransformer {
            it.throttleFirst(500, TimeUnit.MILLISECONDS)
        }
    }

    fun <R> withSchedulers(): ObservableTransformer<R, R> {
        return ObservableTransformer {
            it.subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
        }
    }

    fun <R> withSchedulers(subscribeOn: Scheduler, observeOn: Scheduler): ObservableTransformer<R, R> {
        return ObservableTransformer {
            it.subscribeOn(subscribeOn)
                    .observeOn(observeOn)
        }
    }

    fun <R> withSchedulersIo(): ObservableTransformer<R, R> {
        return ObservableTransformer {
            it.subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
        }
    }

    fun emptyErrorConsumer(): Consumer<Throwable> {
        return Consumer {
            if (BuildConfig.DEBUG) it.printStackTrace()
        }
    }

    fun <R> emptyConsumer(): Consumer<R> {
        return Consumer { }
    }
}