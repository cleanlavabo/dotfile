package project.bee.notex.ui.main


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.jakewharton.rxbinding2.view.clicks
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.functions.Consumer
import io.reactivex.subjects.PublishSubject
import kotlinx.android.synthetic.main.item_category.view.*
import project.bee.notex.R
import project.bee.notex.util.RxUtil

class NotebookAdapter(private val context: Context,
                      private val notebooks: MutableList<NotebookViewModel>) :
        RecyclerView.Adapter<NotebookAdapter.ViewHolder>() {
    private var selectedAt = 0
    val notebookClick: PublishSubject<NotebookViewModel> = PublishSubject.create<NotebookViewModel>()

    fun addCategory(notebook: NotebookViewModel) {
        notebooks.add(notebook)
        notifyItemInserted(notebooks.size)
    }

    fun removeCategory(notebook: NotebookViewModel) {
        notebooks.remove(notebook)
        notifyItemRemoved(notebooks.size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context)
                .inflate(R.layout.item_category, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val category = notebooks[position]
        category.notebook.name.let {
            holder.tvTitle.text = category.notebook.name
            if (category.isSelected) {
                activeBackground(holder)
            } else {
                inactiveBackground(holder)
            }
        }

        categoryClicks(holder, category, position)
    }

    private fun activeBackground(holder: ViewHolder) {
        holder.layoutCategory.setBackgroundColor(ContextCompat.getColor(context, R.color.colorActive))
    }

    private fun inactiveBackground(holder: ViewHolder) {
        holder.layoutCategory.setBackgroundColor(ContextCompat.getColor(context, R.color.colorWhite))
    }

    private fun categoryClicks(holder: ViewHolder, notebook: NotebookViewModel, position: Int) {
        holder.disposable?.dispose()

        holder.disposable = holder.itemView.clicks()
                .compose(RxUtil.withShortThrottleFirst())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(Consumer {
                    val selectedCategory = notebooks[selectedAt]
                    selectedCategory.isSelected = false
                    notebook.isSelected = true
                    selectedAt = position
                    this.notifyDataSetChanged()
                    notebookClick.onNext(notebook)
                }, RxUtil.emptyErrorConsumer())
    }

    override fun getItemCount(): Int = notebooks.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val layoutCategory = view.layoutCategory as ViewGroup
        val tvTitle = view.tvTitle as TextView
        var disposable: Disposable? = null
    }
}
