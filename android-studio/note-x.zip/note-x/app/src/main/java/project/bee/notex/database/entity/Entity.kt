package project.bee.notex.database.entity

import android.os.Parcelable
import androidx.room.*
import kotlinx.android.parcel.Parcelize
import java.util.*

@Parcelize
@Entity(foreignKeys = [ForeignKey(entity = Notebook::class, parentColumns = ["id"], childColumns = ["notebook_uuid"])],
        indices = [Index(value = ["notebook_uuid"])])
data class Note(@PrimaryKey val id: String,
                @ColumnInfo(name = "notebook_uuid") val notebookId: String,
                @ColumnInfo(name = "content") var content: String,
                @ColumnInfo(name = "created_at") var createdAt: Long,
                @ColumnInfo(name = "updated_at") var updatedAt: Long,
                @ColumnInfo(name = "is_active") var isActive: Boolean) : Parcelable {
    @Ignore
    constructor(content: String, notebookUuid: String) : this(UUID.randomUUID().toString(),
            notebookUuid, content, System.currentTimeMillis(), System.currentTimeMillis(), true)
}

@Parcelize
@Entity
data class Notebook(@PrimaryKey val id: String,
                    @ColumnInfo(name = "name") val name: String,
                    @ColumnInfo(name = "created_at") val createdAt: Long,
                    @ColumnInfo(name = "updated_at") val updatedAt: Long,
                    @ColumnInfo(name = "is_active") var isActive: Boolean) : Parcelable {
    @Ignore
    constructor(name: String) : this(UUID.randomUUID().toString(),
            name, System.currentTimeMillis(), System.currentTimeMillis(), true)
}