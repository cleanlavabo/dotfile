package project.bee.notex.ui.editnote

import io.reactivex.Completable
import io.reactivex.Single
import project.bee.notex.database.NoteDatabaseImpl
import project.bee.notex.database.entity.Note

interface EditNoteRepo {
    fun deleteNote(note: Note): Completable

}

class EditNoteRepoImpl(val database: NoteDatabaseImpl) : EditNoteRepo {
    override fun deleteNote(note: Note): Completable {
        return Completable.fromAction {
            database.noteDao().removeNote(note)
        }
    }
}