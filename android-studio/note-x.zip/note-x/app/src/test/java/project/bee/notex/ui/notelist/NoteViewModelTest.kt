package project.bee.notex.ui.notelist

import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class NoteViewModelTest {

    @Before
    fun setUp() {
    }

//    @Test
//    fun givenNote_whenGetFirstLineWorks_thenCorrect() {
//        val content = StringBuilder("aaabbbccc").append("\n").append("dddeeefff")
//        val note = Note(content.toString())
//        val firstLine = note.getFirstLine()
//        assertEquals("aaabbbccc", firstLine)
//
//        val note1 = Note()
//        assertEquals(note1.content, "")
//        assertEquals(note1.getFirstLine(), "")
//    }
//
//    @Test
//    fun givenNote_whenGetFormattedTitleWorks_thenCorrect() {
//        val content = StringBuilder("aaabbbccc").append("\n").append("dddeeefff")
//        val note = Note(content.toString())
//        val title = note.getFormattedTitle()
//        assertEquals("aaabbbccc", title)
//    }
//
//    @Test
//    fun givenNote_whenGetFormattedContentWorks_thenCorrect() {
//        val content = StringBuilder("aaabbbccc").append("\n").append("dddeeefff")
//        val note = Note(content.toString())
//        val formattedContent = "dddeeefff"
//        assertEquals(formattedContent, note.getFormattedContent())
//
//
//        val content1 = StringBuilder("aaabbbccc")
//                .append("\n")
//                .append("dddeeefff")
//                .append("\n")
//                .append("           abc")
//        val note1 = Note(content1.toString())
//        val formattedContent1 = "dddeeefff            abc"
//        assertEquals(formattedContent1, note1.getFormattedContent())
//
//        val content2 = StringBuilder("aaabbbccc")
//                .append("\n")
//                .append("dddeeefff")
//                .append("\n")
//                .append("           abc")
//                .append("\n")
//                .append("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
//                .append("\n")
//                .append("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbb")
//        val note2 = Note(content2.toString())
//        val formattedContent2 = "dddeeefff            abc aaaaaaaaaaaaaaaaaaaaaaaaa"
//        assertEquals(formattedContent2, note2.getFormattedContent())
//
//    }
//
//    @Test
//    fun givenString_whenSubstringWorks_thenCorrect() {
//        val input = "Hello world"
//        val expected = "world"
//        val actual = input.substring("Hello ".length, input.length)
//        assertEquals(expected, actual)
//    }
//
//    @Test
//    fun givenString_whenSplitWorks_thenCorrect() {
//        val content = "abc abcdef"
//        val result = content.split("abc")
//        assertEquals("", result[0])
//        assertEquals(" ", result[1])
//        assertEquals("def", result[2])
//    }

    @Test
    fun `test indexOf`() {
        val content = "\n\nabc abcdef"
        val word = "abc"
        val index = content.indexOf(word)
        assertEquals(2, index)

        val subString = content.substring(2, 5)
        assertEquals("abc", subString)

        val subString2 = content.substring(index + word.length, content.length)
        assertEquals(" abcdef", subString2)
    }
}