package project.bee.notex

import android.app.Application
import project.bee.notex.di.component.AppComponent
import project.bee.notex.di.component.DaggerAppComponent
import project.bee.notex.di.module.AppModule
import timber.log.Timber

class App : Application() {
    val appComponent: AppComponent by lazy {
        DaggerAppComponent.builder()
                .appModule(AppModule(this))
                .build()
    }

    companion object {
        lateinit var instance: App
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        initTimberInDebugMode()
        di()
    }

    private fun di() {
        appComponent.inject(this)
    }

    private fun initTimberInDebugMode() {
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
    }
}